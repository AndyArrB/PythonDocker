create definer = root@localhost view vista_aviones as
select `aeropuerto`.`aviones`.`id`      AS `id`,
       `aeropuerto`.`aviones`.`modelo`  AS `modelo`,
       `aeropuerto`.`aviones`.`id_base` AS `id_base`
from `aeropuerto`.`aviones`;

