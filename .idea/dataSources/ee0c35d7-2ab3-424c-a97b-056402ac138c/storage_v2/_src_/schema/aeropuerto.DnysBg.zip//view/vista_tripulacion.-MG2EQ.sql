create definer = root@localhost view vista_tripulacion as
select `aeropuerto`.`miembros_tripulacion`.`id`       AS `id`,
       `aeropuerto`.`miembros_tripulacion`.`nombre`   AS `nombre`,
       `aeropuerto`.`miembros_tripulacion`.`apellido` AS `apellido`,
       `aeropuerto`.`miembros_tripulacion`.`id_base`  AS `id_base`
from `aeropuerto`.`miembros_tripulacion`;

