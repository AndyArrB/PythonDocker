create definer = root@localhost view vista_bases as
select `aeropuerto`.`bases`.`id`        AS `id`,
       `aeropuerto`.`bases`.`nombre`    AS `nombre`,
       `aeropuerto`.`bases`.`ubicacion` AS `ubicacion`
from `aeropuerto`.`bases`;

