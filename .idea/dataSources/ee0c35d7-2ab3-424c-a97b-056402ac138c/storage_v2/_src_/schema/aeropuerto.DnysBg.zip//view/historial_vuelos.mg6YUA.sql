create definer = root@localhost view historial_vuelos as
select `v`.`id`                                                               AS `id_vuelo`,
       `v`.`numero_vuelo`                                                     AS `numero_vuelo`,
       `v`.`origen`                                                           AS `origen`,
       `v`.`destino`                                                          AS `destino`,
       `v`.`fecha_horaSalida`                                                 AS `fecha_horaSalida`,
       `p`.`id`                                                               AS `id_piloto`,
       `p`.`nombre`                                                           AS `nombre_piloto`,
       `p`.`apellido`                                                         AS `apellido_piloto`,
       `a`.`id`                                                               AS `id_avion`,
       `a`.`modelo`                                                           AS `modelo`,
       group_concat(concat(`t`.`nombre`, ' ', `t`.`apellido`) separator ', ') AS `tripulacion`
from (((((`aeropuerto`.`vuelos` `v` join `aeropuerto`.`pilotos_vuelo` `pv`
          on ((`v`.`id` = `pv`.`id_vuelo`))) join `aeropuerto`.`pilotos` `p`
         on ((`pv`.`id_piloto` = `p`.`id`))) join `aeropuerto`.`aviones` `a`
        on ((`v`.`id_avion` = `a`.`id`))) left join `aeropuerto`.`vuelos_tripulacion` `vt`
       on ((`v`.`id` = `vt`.`id_vuelo`))) left join `aeropuerto`.`miembros_tripulacion` `t`
      on ((`vt`.`id_tripulacion` = `t`.`id`)))
group by `v`.`id`, `v`.`numero_vuelo`, `v`.`origen`, `v`.`destino`, `v`.`fecha_horaSalida`, `p`.`id`, `p`.`nombre`,
         `p`.`apellido`, `a`.`id`, `a`.`modelo`;

