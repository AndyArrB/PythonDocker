create definer = root@localhost view vista_pilotos as
select `aeropuerto`.`pilotos`.`id`               AS `id`,
       `aeropuerto`.`pilotos`.`nombre`           AS `nombre`,
       `aeropuerto`.`pilotos`.`apellido`         AS `apellido`,
       `aeropuerto`.`pilotos`.`horasVuelo_total` AS `horasVuelo_total`,
       `aeropuerto`.`pilotos`.`id_base`          AS `id_base`
from `aeropuerto`.`pilotos`;

